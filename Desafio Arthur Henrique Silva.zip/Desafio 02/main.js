const listElement = document.querySelector('ul')
const inputElement = document.querySelector('input')
const buttonElement = document.querySelector('button')

var por_veiculo;

document.getElementById("valor_carro").disabled = true;
document.getElementById("valor_taxas").disabled = true;
document.getElementById("taxas_carro").disabled = true;
document.getElementById("fim_parcelas").disabled = true;

const tarefas = JSON.parse(localStorage.getItem('list_tarefas')) || []


function addTerefa() {
    var nome = document.getElementById("nome").value;
    var cpf = document.getElementById("cpf").value;
    var sexo = document.querySelector('input[name="genero"]:checked').value;
    var dtnascimento = document.getElementById("nascimento").value;
    var nm_veiculo = document.getElementById("nm_veiculo").value;
    var val_veiculo = document.getElementById("val_veiculo").value;

    //repetição do código acima, foi a única maneira que eu conseguir aplicar Var Idade sem erro
    var data = document.getElementById("nascimento").value;
    data = data.replace(/\//g, "-");
    var data_array = data.split("-");
    if(data_array[0].length != 4){
        data = data_array[2]+"-"+data_array[1]+"-"+data_array[0];
    }
    var hoje = new Date();
    var nasc  = new Date(data);
    var idade = hoje.getFullYear() - nasc.getFullYear();

    //Calculo de seguro

    var total_veiculo = document.getElementById("val_veiculo").value;
    var sex = document.querySelector('input[name="genero"]:checked').value;
    var parcelas = document.getElementById("parcelas").value;

    porcen_veiculo = (total_veiculo/100)*3;

    document.getElementById('valor_carro').value = "O valor do percentual é igual: "+ porcen_veiculo;

    if(sex=="M"){
        if(idade >= 18 && idade <= 25){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*20/100);
        }
        if(idade >= 26 && idade <= 30){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*15/100);
        }
        if(idade >= 31 && idade <= 35){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*12/100);
        }
        if(idade >= 36){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*10/100);
        }
    }
    else{
        if(idade >= 18 && idade <= 25){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*10/100);
        }
        if(idade >= 26 && idade <= 30){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*5/100);
        }
        if(idade >= 31 && idade <= 35){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*2/100);
        }
        if(idade >= 36){
            porcen_veiculo = (total_veiculo/100)*3;
        }
    }

    var to_parcelas;
    var cada_parcela;

    if(parcelas >= 1 && parcelas <= 5){
        to_parcelas = porcen_veiculo/parcelas;
    }
    if(parcelas >= 6 && parcelas <= 9){
        to_parcelas = (porcen_veiculo+(porcen_veiculo*3/100));
        cada_parcela = to_parcelas/parcelas;

    }
    if(parcelas >= 10 && parcelas <= 12){
        to_parcelas = (porcen_veiculo+(porcen_veiculo*5/100));
        cada_parcela = to_parcelas/parcelas;
        document.getElementById('fim_parcelas').value = "Fica "+ to_parcelas + " em " + parcelas + " Parcelas dê R$"+ cada_parcela;
    }

    var randomized = Math.ceil(Math.random() * Math.pow(10,5));//Cria um número aleatório do tamanho definido em size.
	var digito = Math.ceil(Math.log(randomized));//Cria o dígito verificador inicial
	while(digito >= 1){//Pega o digito inicial e vai refinando até ele ficar menor que dez
		digito = Math.ceil(Math.log(digito));
	}
	var id_calculo = randomized + '-' + digito;//Cria a ID


    tarefas.push("Nome: "+nome,"CPF: "+cpf,"Sexo: "+sexo,"Data de nascimento: "+ dtnascimento,"Nome do veiculo: "+nm_veiculo,"Preço total veiculo: "+val_veiculo,"Preço seguro (%3): " + porcen_veiculo , "id: "+id_calculo,"Preço por parcela: "+cada_parcela,"Parcelas: "+parcelas,"Total Parcelas: "+to_parcelas);

    salvarNoLocalStorage()
}

buttonElement.setAttribute('onclick', 'addTerefa()')

function salvarNoLocalStorage() {
    localStorage.setItem('list_tarefas', JSON.stringify(tarefas))
}


// Valida Data

function validadata(){
    var data = document.getElementById("nascimento").value; // pega o valor do input
    data = data.replace(/\//g, "-"); // substitui eventuais barras (ex. IE) "/" por hífen "-"
    var data_array = data.split("-"); // quebra a data em array
     
    // para o IE onde será inserido no formato dd/MM/yyyy
    if(data_array[0].length != 4){
       data = data_array[2]+"-"+data_array[1]+"-"+data_array[0]; // remonto a data no formato yyyy/MM/dd
    }
     
    // comparo as datas e calculo a idade
    var hoje = new Date();
    var nasc  = new Date(data);
    var idade = hoje.getFullYear() - nasc.getFullYear();
    var m = hoje.getMonth() - nasc.getMonth();
 
    if (m < 0 || (m === 0 && hoje.getDate() < nasc.getDate())) idade--;
       if(idade < 18){
          alert("Pessoas menores de 18 não podem se cadastrar.");
          document.getElementById('nascimento').value = "";
          return false;
       }
  
    if(idade >= 18 && idade <= 100){
        return true;
    }
     
    else{
      document.getElementById('nascimento').value = "";
      alert("Data incogruente.");
    }
}

function mostrar(){

    //calculo de idade
    var data = document.getElementById("nascimento").value;
    data = data.replace(/\//g, "-");
    var data_array = data.split("-");
    if(data_array[0].length != 4){
        data = data_array[2]+"-"+data_array[1]+"-"+data_array[0];
    }
    var hoje = new Date();
    var nasc  = new Date(data);
    var idade = hoje.getFullYear() - nasc.getFullYear();

    //Demonstração pro cliente

    var total_veiculo = document.getElementById("val_veiculo").value;
    var sex = document.querySelector('input[name="genero"]:checked').value;
    var parcelas = document.getElementById("parcelas").value;

    porcen_veiculo = (total_veiculo/100)*3;

    document.getElementById('valor_carro').value = "O valor do percentual é igual: "+ porcen_veiculo;

    if(sex=="M"){
        if(idade >= 18 && idade <= 25){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*20/100);
            document.getElementById('valor_taxas').value = "O valor do percentual mais as taxas (20%) é igual: "+ porcen_veiculo;
        }
        if(idade >= 26 && idade <= 30){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*15/100);
            document.getElementById('valor_taxas').value = "O valor do percentual mais as taxas (15%) é igual: "+ porcen_veiculo;
        }
        if(idade >= 31 && idade <= 35){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*12/100);
            document.getElementById('valor_taxas').value = "O valor do percentual mais as taxas (13%) é igual: "+ porcen_veiculo;
        }
        if(idade >= 36){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*10/100);
            document.getElementById('valor_taxas').value = "O valor do percentual mais as taxas (10%) é igual: "+ porcen_veiculo;
        }
    }
    else{
        if(idade >= 18 && idade <= 25){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*10/100);
            document.getElementById('valor_taxas').value = "O valor do percentual mais as taxas (10%) é igual: "+ porcen_veiculo;
        }
        if(idade >= 26 && idade <= 30){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*5/100);
            document.getElementById('valor_taxas').value = "O valor do percentual mais as taxas (5%) é igual: "+ porcen_veiculo;
        }
        if(idade >= 31 && idade <= 35){
            porcen_veiculo = (total_veiculo/100)*3+(((total_veiculo/100)*3)*2/100);
            document.getElementById('valor_taxas').value = "O valor do percentual mais as taxas (2%) é igual: "+ porcen_veiculo;
        }
        if(idade >= 36){
            porcen_veiculo = (total_veiculo/100)*3;
            document.getElementById('valor_taxas').value = "O valor do percentual, não possui taxas é igual: "+ porcen_veiculo;
        }
    }
    var to_parcelas;
    var cada_parcela;

    if(parcelas >= 1 && parcelas <= 5){
        to_parcelas = porcen_veiculo/parcelas;
        document.getElementById('fim_parcelas').value = "Fica "+ porcen_veiculo + " em " + parcelas + " Parcelas dê R$"+ to_parcelas;
    }
    if(parcelas >= 6 && parcelas <= 9){
        to_parcelas = (porcen_veiculo+(porcen_veiculo*3/100));
        cada_parcela = to_parcelas/parcelas;
        document.getElementById('fim_parcelas').value = "Fica "+ to_parcelas + " em " + parcelas + " Parcelas dê R$"+ cada_parcela;
    }
    if(parcelas >= 10 && parcelas <= 12){
        to_parcelas = (porcen_veiculo+(porcen_veiculo*5/100));
        cada_parcela = to_parcelas/parcelas;
        document.getElementById('fim_parcelas').value = "Fica "+ to_parcelas + " em " + parcelas + " Parcelas dê R$"+ cada_parcela;
    }
}