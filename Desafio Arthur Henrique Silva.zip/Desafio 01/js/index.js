function validar(){

    var saque = parseInt(document.getElementById("num").value);
    var mult = 5;

        if (saque%mult != 0) {
            alert(saque+" não é multiplo de 5.");
            document.getElementById('num').value = "";
            document.getElementById("notas").style.display = "none";
        }
        else{
            document.getElementById('num').value = saque;
            document.getElementById("notas").style.display = "block";
        }
}

function clicar(){
    var valor = parseInt(document.getElementById("num").value);

    var notas = [100, 50, 20, 10, 5]
    var troco = {'100': 0, '50': 0, '20': 0, '10': 0, '5': 0}

    var resposta = document.getElementById('resposta');

    for (var nota of notas) {
        while (valor >= nota) {
          troco[nota] += 1
          valor -= nota
        }
      }

      n100.innerHTML = troco['100'];
      n50.innerHTML = troco['50'];
      n20.innerHTML = troco['20'];
      n10.innerHTML = troco['10'];
      n5.innerHTML = troco['5'];
}

